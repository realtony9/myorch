#!/usr/bin/env python


import json
import os
from jinja2 import Template


def read_usecase(usecase_file):
    jfile = open(usecase_file)
    jfile_str = jfile.read()
    usecase_dict = json.loads(jfile_str)
    assert isinstance(usecase_dict, object)
    return usecase_dict


def get_dict(dict_value, slice):
    return dict_value.values()[slice]


def list_keys(dict):
    for key in dict:
        print key


def capture_input(input_dict):
    new_dict = {}
    for k in input_dict:
        inp =raw_input("Please enter " + input_dict[k] + " detail: ")
        new_dict[k] = inp

    return new_dict

def get_user_input(nid_dict):
    while(1):
        for k in nid_dict:
            print k
        nid_role = raw_input("Select the NID function from the above list: ")
        if nid_role in nid_dict:
            input_dict = capture_input(nid_dict[nid_role])
            input_dict['nid_role'] = nid_role
            break
        else:
            print "Nid role not found"
    return input_dict


def render_template(user_input, usecase, nid):

    usecase_dir = "templates/" + usecase
    template_file = usecase_dir + "/" + user_input['nid_role'] + ".j2"
    render_dir = "rendered_config/latest.conf"

    if (os.path.isdir(usecase_dir)):
        if (os.path.exists(template_file)):
            # --- start rendering
            template = Template(open(template_file).read())
            rendered_config = template.render(user_input)
            with open(render_dir, 'w') as config:
                config.write(rendered_config)
        else:
            print "J2 template does not exist"
            exit()
    else:
        print "Usecase directory does not exist"
        exit()



def provision_usecase(usecase_dict, usecase, nid):
    user_input = get_user_input(usecase_dict[usecase]['vendor'][nid])
    render_template(user_input, usecase, nid)


